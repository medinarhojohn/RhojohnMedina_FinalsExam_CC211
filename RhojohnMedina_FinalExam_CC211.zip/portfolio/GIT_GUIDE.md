# Git & GitHub Commands (Task 5)

Run these yourself in Git Bash or CMD from inside the project folder. The exam requires command-line upload and at least 3 meaningful commits.

```bash
git config --global user.name "Rhojohn Medina"
git config --global user.email "your-email@example.com"

git init
git branch -M main

# Commit 1
git add index.html assets/css/style.css assets/images
git commit -m "Add home page layout, styling, and images"

# Commit 2
git add pages assets/js
git commit -m "Add projects and contact pages with JavaScript features"

# Commit 3
git add README.md PROMPT_LOG.md docs
git commit -m "Add documentation, prompt log, and screenshots folder"

# Create an empty repo on github.com first (no README), then:
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main

git log --oneline
```

Take screenshots of the push output and `git log --oneline`, save them in `docs/screenshots/`, then commit and push again. Make sure the repo is public or the instructor is added as a collaborator.
