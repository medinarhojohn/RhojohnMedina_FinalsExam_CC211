# PROMPT_LOG

> **Important:** The entries below are drafts of prompts that match how this project was planned and built. Your instructor expects the **exact prompts you entered**. Replace or edit each entry so it reflects what you actually ran, and make sure the technique names match the list covered in class (for example Zero-shot, Few-shot, Role prompting, Chain-of-Thought, RTF/CRISPE-style frameworks, Iterative refinement).

---

## Entry 1: Project planning
- **Technique or framework:** Role prompting + RTF (Role, Task, Format)
- **Purpose:** Choose a feasible project and define scope (Task 1).
- **Exact prompt:**
  ```
  Act as a senior web development instructor. I am a college student taking CC211 and must build a frontend-only web app using HTML, CSS, JavaScript, and Bootstrap with at least 3 pages, 3 JavaScript features, and a validated form. Compare an interactive personal portfolio and an expense tracker, then recommend one I can finish in a few hours. Respond with: project title, problem, target users, objectives, main features, and planned pages in a table.
  ```
- **Result summary:** The AI recommended an interactive personal portfolio and produced the project definition.
- **Evaluation:** Correct: scope was realistic. Missing: nothing required. Needed more personalization.
- **Improvement:** Manually added my own name, interests, and course details.

## Entry 2: Application build
- **Technique or framework:** Context + Constraints + Expected Output (structured prompt), Few-shot (file structure example)
- **Purpose:** Generate the full application files.
- **Exact prompt:**
  ```
  Context: I am building "Rhojohn Medina Portfolio" for a college exam. Constraints: frontend only; HTML, CSS, JavaScript, Bootstrap 5 via CDN; separate files; pages: index.html, pages/projects.html, pages/contact.html; responsive; accessible labels and visible focus; no backend. Required JS: skills filter, project search/filter/sort, add/remove projects with localStorage, contact form validation with feedback. Expected output: complete code for every file following this structure: index.html, pages/, assets/css/style.css, assets/js/script.js, assets/images/.
  ```
- **Result summary:** The AI produced all three pages, a stylesheet, a script, and placeholder images.
- **Evaluation:** Correct: structure, navigation, features. Errors: one error message on the textarea did not display because of its nesting. Missing: documentation.
- **Improvement:** Added a CSS rule to show the textarea feedback; asked for README and PROMPT_LOG in the next prompt.

## Entry 3: Chain-of-Thought testing
- **Technique or framework:** Chain-of-Thought
- **Purpose:** Find bugs before submission (Task 4).
- **Exact prompt:**
  ```
  Review my script.js step by step. For each feature (skills filter, project search/sort, add/remove project, contact form), trace what happens with valid, invalid, and empty input, then list any bugs and the exact fix.
  ```
- **Result summary:** The AI traced each feature and listed edge cases.
- **Evaluation:** Correct: validation paths. Needs checking in a real browser.
- **Improvement:** Tested manually and logged the results in README.md.

## Entry 4: Iterative refinement
- **Technique or framework:** Iterative refinement / self-critique
- **Purpose:** Improve accessibility and responsiveness.
- **Exact prompt:**
  ```
  Critique the UI against these criteria: color contrast, keyboard focus, form labels, and layout at 375px, 768px, and 1280px. Then give the minimal CSS/HTML changes to fix each problem.
  ```
- **Result summary:** The AI suggested focus styles, a skip link, and reduced-motion support.
- **Evaluation:** Correct: all suggestions applied. Missing: real device testing.
- **Improvement:** Checked in browser dev tools responsive mode.

## Entry 5: Documentation
- **Technique or framework:** RTF + output template
- **Purpose:** Produce README.md and a Git command guide.
- **Exact prompt:**
  ```
  You are a technical writer. Write README.md for my portfolio project with these sections: title/description, student name and section, users and objectives, features and technologies, how to open, AI tools used, testing and corrections, limitations, credits. Use tables where helpful.
  ```
- **Result summary:** README with placeholders for testing results.
- **Evaluation:** Correct structure; testing results must come from my own testing.
- **Improvement:** Filled in real results after testing.
