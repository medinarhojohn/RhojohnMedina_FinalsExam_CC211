# Rhojohn Medina | Interactive Personal Portfolio

A responsive, frontend-only personal portfolio built for the **CC211 Finals Laboratory Examination** (A.Y. 2025-2026), Institute of Computing Studies, Polytechnic College of Botolan.

> This is a **frontend demonstration**. There is no backend, login, or real email sending. Data is stored only in your browser's `localStorage`.

## Student Information
- **Name:** Rhojohn Medina
- **Section:** _(fill in your section)_
- **Course:** CC211 - Application Development and Emerging Technologies

## Task 1: Project Definition
- **Problem / need:** Students need a simple way to present who they are, what they can do, and their work to classmates, instructors, and future employers.
- **Target users:** Instructors, classmates, internship recruiters, and potential collaborators.
- **Objectives:**
  1. Present a personal introduction, skills, and interests clearly.
  2. Let visitors explore projects with search, filter, and sort.
  3. Provide a validated contact form with immediate feedback.
  4. Demonstrate responsive, accessible, consistent UI/UX.
- **Main features:** theme toggle, skills filter, animated statistics, project search/filter/sort, add/remove projects, validated contact form, saved messages.
- **Pages:** Home (`index.html`), Projects (`pages/projects.html`), Contact (`pages/contact.html`).

## Features
| # | JavaScript feature | Where |
|---|---|---|
| 1 | Skills category filter (renders list dynamically) | Home |
| 2 | Project search, category filter, and sorting | Projects |
| 3 | Add and remove projects, saved with `localStorage` | Projects |
| 4 | Contact form validation with feedback, messages saved and deletable | Contact |
| 5 | Light/dark theme toggle remembered in `localStorage` | All pages |
| 6 | Live character counter and animated stat counters | Contact / Home |

## Technologies
HTML5, CSS3, JavaScript (ES6), Bootstrap 5.3 (CDN), Bootstrap Icons (CDN), Git/GitHub.

## How to Open and Use
1. Download or clone the repository.
2. Open `index.html` in a modern browser (internet needed for the Bootstrap CDN).
3. Use the navbar to move between pages. On Projects, try searching, filtering, sorting, and adding a project. On Contact, submit the form with valid, invalid, and empty values.

```
portfolio/
├── index.html
├── pages/ (projects.html, contact.html)
├── assets/ (css/style.css, js/script.js, images/)
├── docs/screenshots/
├── README.md
└── PROMPT_LOG.md
```

## AI Tools Used and Contributions
- **Claude (Anthropic):** generated the initial project structure, HTML pages, CSS, JavaScript features, and draft documentation.
- **My contribution:** choosing the project, reviewing and testing all code, personalizing content, fixing issues, and running the Git workflow myself.
- See `PROMPT_LOG.md` for prompts and evaluations.

## Testing Performed and Corrections Made
| Check | Result | Correction |
|---|---|---|
| Navigation links across all pages | _fill in after testing_ | |
| Contact form: empty, invalid email, short message, valid | _fill in_ | |
| Project search, filter, sort, add, remove | _fill in_ | |
| Responsive layout at ~375px, ~768px, ~1280px | _fill in_ | |
| Browser console errors | _fill in_ | |
| localStorage persistence after refresh | _fill in_ | |

_Replace the placeholders with the real issues you found and how you fixed them._

## Known Limitations
- No backend: messages are not delivered anywhere.
- Data lives only in one browser and is lost if site data is cleared.
- Bootstrap and icons load from a CDN, so offline use needs internet on first load.
- Project images are placeholder illustrations.

## Credits
- [Bootstrap 5.3](https://getbootstrap.com/) and [Bootstrap Icons](https://icons.getbootstrap.com/) (MIT).
- Illustrations (`assets/images/*.svg`) created for this project.
- Code drafted with Claude (Anthropic) and reviewed by the student.
