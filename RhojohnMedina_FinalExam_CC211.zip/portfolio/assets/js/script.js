/* Rhojohn Medina Portfolio - script.js
   Frontend-only demonstration. Data is stored in the browser (localStorage). */
(function () {
  "use strict";

  // ---------- Helpers ----------
  const BASE = document.body.dataset.base || ""; // "" on index, "../" inside /pages
  const KEYS = { theme: "rm_theme", projects: "rm_custom_projects", messages: "rm_messages" };

  function load(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) { return fallback; }
  }
  function save(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch (e) { return false; }
  }
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  // ---------- Sample data ----------
  const SKILLS = [
    { name: "HTML & CSS", level: 85, cat: "frontend" },
    { name: "JavaScript", level: 70, cat: "frontend" },
    { name: "Bootstrap", level: 80, cat: "frontend" },
    { name: "Git & GitHub", level: 65, cat: "tools" },
    { name: "VS Code", level: 85, cat: "tools" },
    { name: "Prompt Engineering", level: 70, cat: "tools" },
    { name: "Logo & Brand Design", level: 75, cat: "creative" },
    { name: "Writing & Storytelling", level: 80, cat: "creative" }
  ];

  const DEFAULT_PROJECTS = [
    { id: "p1", title: "Bale Kapampangan Logo", category: "Design", year: 2026,
      desc: "A logo concept for a brand celebrating Kapampangan food and culture.",
      image: "assets/images/project-1.svg", tags: ["Branding", "Logo"] },
    { id: "p2", title: "Salita ng Taon", category: "Writing", year: 2026,
      desc: "A FIL 111 project that highlights meaningful Filipino words of the year.",
      image: "assets/images/project-2.svg", tags: ["Filipino", "Research"] },
    { id: "p3", title: "Interactive Portfolio", category: "Web", year: 2026,
      desc: "This responsive site built with HTML, CSS, JavaScript, and Bootstrap.",
      image: "assets/images/project-3.svg", tags: ["HTML", "CSS", "JavaScript"] }
  ];

  // ---------- Theme toggle (feature: saved preference) ----------
  function applyTheme(theme) {
    document.documentElement.setAttribute("data-bs-theme", theme);
    const btn = document.getElementById("themeToggle");
    if (btn) {
      btn.querySelector(".theme-label").textContent = theme === "dark" ? "Light" : "Dark";
      btn.querySelector("i").className = theme === "dark" ? "bi bi-sun-fill" : "bi bi-moon-stars-fill";
    }
  }
  function initTheme() {
    const saved = load(KEYS.theme, null);
    const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    applyTheme(saved || (prefersDark ? "dark" : "light"));
    const btn = document.getElementById("themeToggle");
    if (btn) {
      btn.addEventListener("click", function () {
        const next = document.documentElement.getAttribute("data-bs-theme") === "dark" ? "light" : "dark";
        applyTheme(next);
        save(KEYS.theme, next);
      });
    }
  }

  // ---------- Home: skills filter + counters ----------
  function renderSkills(filter) {
    const list = document.getElementById("skillList");
    if (!list) return;
    const items = SKILLS.filter(function (s) { return filter === "all" || s.cat === filter; });
    list.innerHTML = items.map(function (s) {
      return '<div class="col-sm-6 col-lg-3"><div class="skill-card h-100">' +
        '<div class="d-flex justify-content-between mb-2"><strong>' + escapeHtml(s.name) + '</strong><span>' + s.level + '%</span></div>' +
        '<div class="progress" role="progressbar" aria-label="' + escapeHtml(s.name) + ' proficiency" aria-valuenow="' + s.level + '" aria-valuemin="0" aria-valuemax="100">' +
        '<div class="progress-bar" style="width:' + s.level + '%"></div></div></div></div>';
    }).join("");
  }
  function initSkills() {
    const wrap = document.getElementById("skillFilters");
    if (!wrap) return;
    renderSkills("all");
    wrap.addEventListener("click", function (e) {
      const btn = e.target.closest("[data-skill-filter]");
      if (!btn) return;
      wrap.querySelectorAll(".btn").forEach(function (b) { b.classList.remove("active"); b.setAttribute("aria-pressed", "false"); });
      btn.classList.add("active");
      btn.setAttribute("aria-pressed", "true");
      renderSkills(btn.dataset.skillFilter);
    });
  }
  function animateCount(el, target) {
    const duration = 700, start = performance.now();
    function step(now) {
      const p = Math.min((now - start) / duration, 1);
      el.textContent = Math.round(target * p);
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  function initStats() {
    const p = document.getElementById("statProjects");
    if (!p) return;
    animateCount(p, DEFAULT_PROJECTS.length + load(KEYS.projects, []).length);
    animateCount(document.getElementById("statSkills"), SKILLS.length);
    animateCount(document.getElementById("statMessages"), load(KEYS.messages, []).length);
  }

  // ---------- Projects page: search, filter, sort, add, remove ----------
  function allProjects() { return DEFAULT_PROJECTS.concat(load(KEYS.projects, [])); }

  function renderProjects() {
    const grid = document.getElementById("projectGrid");
    if (!grid) return;
    const q = document.getElementById("projectSearch").value.trim().toLowerCase();
    const cat = document.getElementById("projectCategory").value;
    const sort = document.getElementById("projectSort").value;

    let items = allProjects().filter(function (p) {
      const text = (p.title + " " + p.desc + " " + p.tags.join(" ")).toLowerCase();
      return (cat === "all" || p.category === cat) && text.indexOf(q) !== -1;
    });
    items.sort(function (a, b) {
      if (sort === "title") return a.title.localeCompare(b.title);
      if (sort === "oldest") return a.year - b.year;
      return b.year - a.year;
    });

    document.getElementById("projectCount").textContent =
      items.length + (items.length === 1 ? " project" : " projects") + " shown";

    if (!items.length) {
      grid.innerHTML = '<div class="col-12"><div class="alert alert-info mb-0" role="status">No projects match your search.</div></div>';
      return;
    }
    grid.innerHTML = items.map(function (p) {
      const isCustom = p.id.indexOf("c_") === 0;
      return '<div class="col-md-6 col-lg-4"><article class="project-card card h-100">' +
        '<img src="' + BASE + escapeHtml(p.image) + '" class="card-img-top" alt="' + escapeHtml(p.title) + ' preview" loading="lazy">' +
        '<div class="card-body d-flex flex-column">' +
        '<div class="d-flex justify-content-between align-items-start mb-1"><h3 class="h5 mb-0">' + escapeHtml(p.title) + '</h3><span class="small text-body-secondary">' + p.year + '</span></div>' +
        '<p class="small text-body-secondary mb-2">' + escapeHtml(p.category) + '</p>' +
        '<p class="flex-grow-1">' + escapeHtml(p.desc) + '</p>' +
        '<div class="mb-2">' + p.tags.map(function (t) { return '<span class="badge badge-tag me-1">' + escapeHtml(t) + '</span>'; }).join("") + '</div>' +
        (isCustom ? '<button type="button" class="btn btn-sm btn-outline-danger align-self-start" data-remove="' + p.id + '"><i class="bi bi-trash" aria-hidden="true"></i> Remove</button>' : '') +
        '</div></article></div>';
    }).join("");
  }

  function initProjects() {
    const grid = document.getElementById("projectGrid");
    if (!grid) return;
    ["projectSearch", "projectCategory", "projectSort"].forEach(function (id) {
      document.getElementById(id).addEventListener("input", renderProjects);
    });
    grid.addEventListener("click", function (e) {
      const btn = e.target.closest("[data-remove]");
      if (!btn) return;
      const remaining = load(KEYS.projects, []).filter(function (p) { return p.id !== btn.dataset.remove; });
      save(KEYS.projects, remaining);
      renderProjects();
    });

    const form = document.getElementById("addProjectForm");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      const title = form.elements.newTitle;
      const category = form.elements.newCategory;
      const desc = form.elements.newDesc;
      let valid = true;
      [title, category, desc].forEach(function (f) { f.classList.remove("is-invalid"); });
      if (title.value.trim().length < 3) { title.classList.add("is-invalid"); valid = false; }
      if (!category.value) { category.classList.add("is-invalid"); valid = false; }
      if (desc.value.trim().length < 10) { desc.classList.add("is-invalid"); valid = false; }
      const status = document.getElementById("addProjectStatus");
      if (!valid) {
        status.className = "alert alert-danger mt-3";
        status.textContent = "Please fix the highlighted fields.";
        return;
      }
      const custom = load(KEYS.projects, []);
      custom.push({
        id: "c_" + Date.now(),
        title: title.value.trim(),
        category: category.value,
        year: new Date().getFullYear(),
        desc: desc.value.trim(),
        image: "assets/images/project-3.svg",
        tags: ["Custom"]
      });
      save(KEYS.projects, custom);
      form.reset();
      status.className = "alert alert-success mt-3";
      status.textContent = "Project added and saved in your browser.";
      renderProjects();
    });
    renderProjects();
  }

  // ---------- Contact page: validated form + saved messages ----------
  function renderMessages() {
    const box = document.getElementById("messageList");
    if (!box) return;
    const msgs = load(KEYS.messages, []);
    if (!msgs.length) {
      box.innerHTML = '<p class="text-body-secondary mb-0">No messages yet. Sent messages appear here (stored only in this browser).</p>';
      return;
    }
    box.innerHTML = msgs.slice().reverse().map(function (m) {
      return '<div class="message-item mb-2"><div class="d-flex justify-content-between gap-2">' +
        '<div><strong>' + escapeHtml(m.name) + '</strong> <span class="small text-body-secondary">&lt;' + escapeHtml(m.email) + '&gt;</span></div>' +
        '<button type="button" class="btn btn-sm btn-outline-danger" data-del="' + m.id + '" aria-label="Delete message from ' + escapeHtml(m.name) + '"><i class="bi bi-trash" aria-hidden="true"></i></button></div>' +
        '<div class="small text-body-secondary">' + escapeHtml(m.subject) + ' &middot; ' + escapeHtml(m.date) + '</div>' +
        '<p class="mb-0 mt-1">' + escapeHtml(m.message) + '</p></div>';
    }).join("");
  }

  function initContact() {
    const form = document.getElementById("contactForm");
    if (!form) return;
    const msgField = form.elements.message;
    const counter = document.getElementById("charCount");
    const MAX = 300;
    msgField.addEventListener("input", function () {
      counter.textContent = msgField.value.length + " / " + MAX;
    });

    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    function check(field, ok, message) {
      const fb = document.getElementById(field.id + "Feedback");
      field.classList.toggle("is-invalid", !ok);
      field.classList.toggle("is-valid", ok);
      if (fb && message) fb.textContent = message;
      return ok;
    }

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      const f = form.elements;
      const name = f.name.value.trim(), email = f.email.value.trim(),
            subject = f.subject.value, message = f.message.value.trim();

      const results = [
        check(f.name, name.length >= 2, name ? "Name must be at least 2 characters." : "Please enter your name."),
        check(f.email, emailRe.test(email), email ? "Enter a valid email like name@example.com." : "Please enter your email."),
        check(f.subject, subject !== "", "Please choose a subject."),
        check(f.message, message.length >= 10 && message.length <= MAX,
              message.length < 10 ? "Message must be at least 10 characters." : "Message must be " + MAX + " characters or fewer.")
      ];

      const status = document.getElementById("formStatus");
      if (results.indexOf(false) !== -1) {
        status.className = "alert alert-danger mt-3";
        status.textContent = "Please correct the errors above and try again.";
        const firstBad = form.querySelector(".is-invalid");
        if (firstBad) firstBad.focus();
        return;
      }
      const msgs = load(KEYS.messages, []);
      msgs.push({ id: "m_" + Date.now(), name: name, email: email, subject: subject, message: message,
                  date: new Date().toLocaleString() });
      const ok = save(KEYS.messages, msgs);
      status.className = ok ? "alert alert-success mt-3" : "alert alert-warning mt-3";
      status.textContent = ok
        ? "Thanks, " + name + "! Your message was saved in this browser (frontend demo, nothing is sent)."
        : "Could not save to browser storage.";
      form.reset();
      form.querySelectorAll(".is-valid").forEach(function (el) { el.classList.remove("is-valid"); });
      counter.textContent = "0 / " + MAX;
      renderMessages();
    });

    document.getElementById("messageList").addEventListener("click", function (e) {
      const btn = e.target.closest("[data-del]");
      if (!btn) return;
      save(KEYS.messages, load(KEYS.messages, []).filter(function (m) { return m.id !== btn.dataset.del; }));
      renderMessages();
    });
    document.getElementById("clearMessages").addEventListener("click", function () {
      save(KEYS.messages, []);
      renderMessages();
    });
    renderMessages();
  }

  // ---------- Init ----------
  document.addEventListener("DOMContentLoaded", function () {
    const year = document.getElementById("year");
    if (year) year.textContent = new Date().getFullYear();
    initTheme();
    initSkills();
    initStats();
    initProjects();
    initContact();
  });
})();
